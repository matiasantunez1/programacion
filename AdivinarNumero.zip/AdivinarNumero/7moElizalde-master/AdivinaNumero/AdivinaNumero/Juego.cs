﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AdivinaNumero
{
    class Juego
    {
        Propiedades prop;
        private int _rango;
        public int numero;
        public int numeroIngresar;
        internal void InicializarJuego()
        {
            //Cargar archivo de parametría
            //Crear objeto Propiedades y completar los valores.

            prop = new Propiedades();

            Console.WriteLine("BIENVENIDO");
           string[] lineas = File.ReadAllLines("rango.txt");
            //_rango = Convert.ToInt32(lineas[0]);
           Console.WriteLine(lineas[0]);
            Random n = new Random();
            numero = n.Next(Convert.ToInt32(lineas[0]));





            /*string[] lineas = File.ReadAllLines("rango.txt");
            foreach (var l in lineas)
            {
                string[] campos = l.Split('=');
                if (campos[0] == "RANGO")
                {
                    _rango = Convert.ToInt32(campos[1]);
                    
                }
                
            }*/



        }

        internal void ComenzarJuego(Jugador jugador)
        {
            Console.Write("Ingrese Nombre del Jugador: ");
            jugador.Nombre = Console.ReadLine();
            jugador.Puntaje = 0;

            Console.WriteLine("Ingrese un numero : ");
            jugador.Puntaje = Convert.ToInt32(Console.ReadLine());
            if (jugador.Puntaje == numero)
            {
                Console.WriteLine("CONGRATULATIONS");

            }

            StreamWriter sw = File.AppendText("archivo.txt");
            sw.WriteLine(jugador.Nombre + "|" + jugador.Puntaje);
            sw.Close();




        }

        internal int SeleccionarOpcion()
        {
            Console.WriteLine("{0}- {1}", (int)Opciones.IntentarNuevamente + 1, Opciones.IntentarNuevamente);
            Console.WriteLine("{0}- {1}", (int)Opciones.MostrarAyuda + 1, Opciones.MostrarAyuda);
            Console.WriteLine("{0}- {1}", (int)Opciones.MostrarMejorPuntaje + 1, Opciones.MostrarMejorPuntaje);
            Console.WriteLine("{0}- {1}", (int)Opciones.Rendirse + 1, Opciones.Rendirse);

            return (Convert.ToInt32(Console.ReadLine()) - 1);
        }

        internal void MostrarAyuda(Jugador jugador)
        {
            if (numero < jugador.Puntaje)
            {
                Console.WriteLine("El numero es menor.");
            }
            else Console.WriteLine("El numero es mayor");
        }

        internal void MostrarMejorPuntaje()
        {
            string[] lineas = File.ReadAllLines("archivo.txt");
            foreach (var l in lineas)
            {
                string[] campos = l.Split('|');

                Convert.ToInt32(campos[1]);
                Console.WriteLine("{0} : {1}",campos[0],campos[1]);
            }

            //Console.WriteLine("MEJOR PUNTAJE {0}: {1}", prop.NombreRecord, prop.PuntajeRecord);


        }

        internal bool AdivinarNumero(Jugador j)
        {
            throw new NotImplementedException();
            
        }

        internal void Reiniciar(Jugador jugador)
        {
            ComenzarJuego(jugador);
        }
    }
}
