﻿namespace AdivinaNumero
{
    internal class Jugador
    {
        public string Nombre { get; internal set; }
        public int Puntaje { get; set; }
    }
}